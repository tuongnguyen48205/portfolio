module StopWatch(
					input clk, 
					input [2:0] in,
					output [6:0] tenths,
					output [5:0] secs, mins
					);
	
	
	// Get the user inputs
	wire red1;
	wire reset;
	RisingEdgeDetector red_start(.clk(clk), .in(!in[0]),
											.out(red1));
	RisingEdgeDetector red_end(.clk(clk), .in(!in[2]),
											.out(reset));
	
	reg start;
	always @(posedge clk) 
		if (red1) 
			start <= !start;

	// Time module
	Time_sw timer_sw(.clk(clk), .start(start), .reset(reset),
					.tenths(tenths), .secs(secs), .mins(mins));
					
endmodule


