module Clock(
				input clk, 
				input [2:0] in, 
				output [5:0] secs, mins,
				output [4:0] hrs,
				output [3:0] flash
				);
				
	// Time module
	Time timer(.clk(clk), .edit(edit),
					.secs(secs), .mins(mins), .hrs(hrs));
	
	// For button control module			
	wire [3:0] edit;
	ButtonControl buttoncontrol(.clk(clk), .key(in), .display(edit));
	
	// For the flash control
	FlashControl flashcontrol(.clk(clk), .key(in[2]), .led(flash));
					
endmodule



