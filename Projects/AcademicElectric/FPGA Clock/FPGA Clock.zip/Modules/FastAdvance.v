module FastAdvance
	#(parameter LONG=25_000_000, PERIOD=5_000_000) (
   input clk,
   input in,
   output out);
    
   localparam BWL = $clog2(LONG+1);
   localparam BWP = $clog2(PERIOD);
   reg [BWL-1:0] cl = 0, next_cl;
   reg [BWP-1:0] cp = 0, next_cp;

   always @(posedge clk) 
       {cl,cp} <= {next_cl,next_cp};

   // Next state logic
   always @(*) begin
	// If the button is being pressed and cl is less than the number of 
   // clock cycles to wait before transitioning to the fast advance 
   // mode, LONG, then increase cl by 1, otherwise if the button is
   // not pressed, set cl back to 0 and if it is, keep cl as what it
   // currently is.
		if (in == 1 && cl < LONG) 
			next_cl = cl + 1;
		else 
			if (in == 0) 
				next_cl = 0;
			else
				next_cl = cl;
	// If the button is being pressed and cl is now equal to the number of 
   // clock cycles to wait before transitioning to the fast advance 
   // mode, LONG, and cp is equal to the period, set cp to 0, otherwise 
   // increase cp to 0. If cl has yet to reach LONG, keep cp as 0
		if (in == 1 && cl == LONG)
			if (cp == PERIOD - 1) 
				next_cp = 0;
			else
				next_cp = cp + 1;
		else 
			next_cp = 0;
	end
  
	// While the button is pressed, output a 1 if cl is 0 (the button is
	// pressed or cl == LONG and cp == 0 (the button is held)
	assign out = (in == 1 && (cl == 0 || (cl == LONG && cp == 0))) ? 1 : 0;
endmodule