module Display(input clk, input [6:0] num, num2, num3, num4, input flash, input [3:0] enable,
					output [6:0] sseg_tens, sseg_ones);
	wire [3:0] digit_tens;
	wire [3:0] digit_ones;
	reg [6:0] temp_num;
	
	always @(*)
		case(enable)
			4'b0001: temp_num = num;
			4'b0010: temp_num = num2;
			4'b0100: temp_num = num3;
			4'b1000:	temp_num = num4;
			default: temp_num = 0;
		endcase
	
	Binary2Decimal digit(.binary(temp_num), .decimal_tens(digit_tens), 
									.decimal_ones(digit_ones));
	
	SSegDecoder digits_tens(.clk(clk), .digit(digit_tens), .flash(flash),
								.sseg(sseg_tens));
	SSegDecoder digits_ones(.clk(clk), .digit(digit_ones), .flash(flash),
								.sseg(sseg_ones));
endmodule



