b = 5.203; k = 100.2001; c = 1.044;
P = tf(c, [1, b, -k]);

z = 9; p = 45; K = 1117;
C = tf(K*[1, z], [1, p]);
L = C*P;

% Spec 1: Phase margin >= 40 deg
margin(L)

% Spec 2: Internal stability - all CL poles LHP
T = feedback(L, 1);
disp(pole(T))

% Spec 3: Complementary sensitivity BW <= 50 rad/s
S = feedback(1, L);
T_comp = 1 - S;

% Find -3dB bandwidth
w = logspace(-1, 3, 1000);
[mag, ~] = bode(T_comp, w);
mag = squeeze(mag);
mag_db = 20*log10(mag);
bw_idx = find(mag_db <= -3, 1);
fprintf('Comp sensitivity BW: %.2f rad/s\n', w(bw_idx))

bode(T_comp)
% Open loop margin plot
figure
margin(L)

figure 
nyquist(L)