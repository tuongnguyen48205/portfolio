# Power Flow Analysis and Voltage Stability Assessment of a Transmission Network

A Newton-Raphson AC power flow solver, independently cross validated,
applied to N-1 contingency screening, meshed vs radial reconfiguration comparison,
voltage stability loading scans, transformer thermal loading checks, and three phase
fault analysis on the WSCC 9-bus transmission test network.

## Contents

```
data/network_9bus.py        Test network dataset (buses, generators, loads, lines, transformers)
src/ybus.py                 Ybus admittance matrix builder (supports branch outages)
src/newton_raphson.py       Newton-Raphson AC power flow solver + branch flow post-processing
src/pandapower_validation.py  PRIMARY validation script
src/gauss_seidel.py          SECONDARY validation solver 
src/network_setup.py        Assembles solver ready arrays from the raw dataset
src/contingency.py          Automated N-1 contingency screening
src/fault_analysis.py       Three phase symmetrical fault analysis (Zbus method)
src/network_diagram.py      Generates the network topology diagram
src/main.py                 Runs every analysis; writes results/results.json and all figures
tests/test_power_flow.py    Automated test suite (9 tests) validating solver correctness
results/results.json        All numerical results from the full analysis run
results/run_log.txt         Console log from the full analysis run
figures/*.png               All 8 figures (7 analysis plots + 1 network diagram)
```

## Reproducing the results

Requires Python 3 with numpy, scipy, matplotlib, pandas (all standard scientific Python).

```bash
cd src
python3 main.py              # runs all analyses, writes results/ and figures/
cd ../tests
python3 test_power_flow.py   # runs the automated test suite
```

## Key findings (see the report for full detail)

- Validation: the primary method is a pandapower cross check. It
  agrees with the custom Newton-Raphson solver within ~3e-6% voltage deviation.
- All three generator step-up transformers island their generator when lost (no N-1
  redundancy in this topology); all six transmission line outages converge, with
  flow redistribution on surviving branches ranging from ~28% to ~253% depending on
  severity.
- Meshed (ring) operation has lower losses and a tighter voltage profile than every
  single line open radial alternative.
- Heavily loaded buses see 5-10% voltage drops at 1.55x-1.9x nominal demand; the
  solver stops converging beyond ~2.2x nominal (approaching voltage collapse).
- Transformer T1 reaches 100% of its thermal rating at ~1.55x nominal demand 
  before the network wide voltage stability limit binds.

## Known limitations (see report Section 7 for full discussion + recommended fixes)

- No PV-bus reactive power limit enforcement.
- Single small test network (9 buses); a larger IEEE test case is recommended future work.
- Voltage collapse boundary identified via solver non convergence rather than a
  continuation power flow trace.
- Fault analysis covers three phase symmetrical faults only.
