module Mode(input clk, in, output reg [1:0] out);
	localparam normal = 2'b00, secs = 2'b01, mins = 2'b10, hrs = 2'b11;
	
	reg [25:0] tracker = 0; // Tracks how much time has passed
	reg enabled = 0; // A flag to check whether a second has passed
	
	// Current state and next state
	reg [1:0] state, next_state;
	initial state = normal;

	// Check that the button has been held for 1 second
	always @(posedge clk) begin
		if (in) begin
			if (tracker < 50_000_000)
				tracker <= tracker + 1'b1;
			else
				enabled <= 1'b1;
	end else begin
        tracker <= 0;
        enabled <= 0;
		end
	end

	// The following is basically the RisingEdgeDetector module
	// to detect that the button has been pressed and not held
	reg prev = 0; // State
	wire next_prev;
	
	always @(posedge clk)
		prev <= next_prev;
		
	assign next_prev = in;
	
	wire press;
	assign press = (!prev && in);

	// Flip flop
	always @(posedge clk) 
		state <= next_state;
		
	// Next state logic
	always @(*) begin
		case (state)
			normal: next_state = (enabled && in) ? secs : normal;
         secs: next_state = (press) ? mins : secs;
         mins: next_state = (press) ? hrs : mins;
         hrs: next_state = (press) ? normal : hrs;
         default: next_state = normal; 
		endcase

		// Output logic
		out = state;
	end
endmodule