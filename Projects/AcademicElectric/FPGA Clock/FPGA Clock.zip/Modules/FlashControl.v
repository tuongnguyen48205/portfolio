module FlashControl(input clk, input key, output [3:0] led);

	// Mode module
	wire [1:0] digit;
	Mode mode(.clk(clk), .in(!key), .out(digit));
	
	// DeMux4 module
	wire [3:0] led_output;
	DeMUX4 demux4(.in(!key), .sel(digit), .out(led_output));

	// The flashing module
	wire flash_out;
	Flash flash(.clk(clk), .out(flash_out));
	
	// Now make it flash
	assign led = (flash_out) ? led_output : 4'b0000;
endmodule