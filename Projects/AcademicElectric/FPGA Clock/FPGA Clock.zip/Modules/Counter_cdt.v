module Counter_cdt
	#(parameter MAX = 1, WIDTH = 1, UP = 1) (
		input clk,
		input reset,
		input increment,
      input enable,
      output reg [WIDTH - 1:0] cnt
	);
	
	initial cnt = 0;
	
	reg [WIDTH-1:0] next_cnt;
 
   always @(posedge clk) begin
		cnt <= next_cnt;
		if (reset) cnt <= 1'd0;
	end
	
	always @(*) 
		if (increment)
			next_cnt = (cnt == MAX) ? 0 : cnt + 1;
		else if (enable && !increment)
			next_cnt = (cnt == 0) ? MAX : cnt - 1;
		else
			next_cnt = cnt;

endmodule



