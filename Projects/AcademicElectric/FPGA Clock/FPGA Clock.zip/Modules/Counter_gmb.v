module Counter_gmb
	#(parameter MAX = 1, WIDTH = 1, UP = 1) (
		input clk,
		input token,
		input reset,
		input increment,
		input decrement,
		input done,
		input [1:0] gamble,
      output reg [WIDTH - 1:0] cnt
	);
	
	reg [WIDTH-1:0] next_cnt;
	
	reg [7:0] tracker = 0;
	reg [7:0] next_tracker;
	initial cnt = (token) ? 25 : 0;
 
   always @(posedge clk) begin
		cnt <= next_cnt;
		tracker <= next_tracker;
		
		if (reset && token) begin
			cnt <= 25;
			tracker <= 0;
		end else if (reset && !token) begin
			cnt <= 0;
			tracker <= 0;
		end else if (gamble == 2'b11 && token) begin
			cnt <= cnt + (2 * tracker);
			tracker <= 0;
		end else if (gamble == 2'b10 && token) begin
			tracker <= 0;
		end else if (gamble[1] == 1 && !token) begin
			cnt <= 0;
			tracker <= 0;
		end
	end
	
	always @(*) 
		if (increment && !done)
			next_cnt = cnt + 1;
		else if (decrement && !done) begin
			next_cnt = cnt - 1;
			next_tracker = tracker + 1;
		end else begin
			next_cnt = cnt;
			next_tracker = tracker;
		end
		
endmodule
