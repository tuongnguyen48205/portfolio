module Gambling(
					input clk,
					input [3:0] in,
					output [6:0] tokens, bet,
					output [1:0] win
					);
					
	wire start;
	wire decrement;
	wire reset;
	FastAdvance minus(.clk(clk), .in(!in[1]), .out(decrement));
	RisingEdgeDetector red_reset(.clk(clk), .in(!in[2]), .out(reset));
	
	reg done = 1'b0;
	always @(*)
		done = (tokens == 0) ? 1'b1 : 1'b0;
	
	Counter_gmb #(.MAX(99), .WIDTH(7)) token(.clk(clk), .token(1), .done(done), .gamble(gamble_start),
				.reset(reset), .increment(0), .decrement(decrement), .cnt(tokens));
	Counter_gmb #(.MAX(99), .WIDTH(7)) bets(.clk(clk), .token(0), .done(done), .gamble(gamble_start),
				.reset(reset), .increment(decrement), .decrement(0), .cnt(bet));
				
				
	// Now for the actual gambling part
	reg out = 0;
	always @(posedge clk) begin
		out <= !out;
	end
	
	wire [1:0] gamble_start;
	reg [1:0] gamble_start_temp;
	reg outcome = 0;
	RisingEdgeDetector red_gamble(.clk(clk), .in(!in[0]), .out(start));
	always @(*)
		if (start) begin
			outcome = out;
			gamble_start_temp = {1'b1, !outcome};
		end else
			gamble_start_temp = {1'b0, 1'b0};
		

	assign win = {!in[0], outcome};
	assign gamble_start =  gamble_start_temp;
	
endmodule