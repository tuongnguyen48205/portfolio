/*
  HX711 Load Cell Calibration
*/

#include <HX711.h>

const int DOUT_PIN = 4;
const int SCK_PIN  = 5;

HX711 scale;

float calibration_factor = -7050.0; // starting guess, adjust via serial
const float KNOWN_WEIGHT_UNITS = 100.0; // label your reference weight, e.g. grams

void setup() {
  Serial.begin(57600);
  Serial.println("HX711 Calibration");
  Serial.println("Remove all weight, then send 't' to tare.");
  Serial.println("Then place known weight and use +/- (or a/z for x10 step) to tune.");

  scale.begin(DOUT_PIN, SCK_PIN);
  scale.set_scale();
  scale.tare();
}

void loop() {
  scale.set_scale(calibration_factor);

  Serial.print("Reading: ");
  Serial.print(scale.get_units(10), 2);
  Serial.print("  cal_factor: ");
  Serial.println(calibration_factor);

  if (Serial.available()) {
    char c = Serial.read();
    switch (c) {
      case '+': calibration_factor += 1;   break;
      case '-': calibration_factor -= 1;   break;
      case 'a': calibration_factor += 10;  break;
      case 'z': calibration_factor -= 10;  break;
      case 'A': calibration_factor += 100; break;
      case 'Z': calibration_factor -= 100; break;
      case 't':
        Serial.println("Taring...");
        scale.tare();
        Serial.println("Tare done.");
        break;
    }
  }

  delay(200);
}
