function analyze_test_log(csvPath)
% Load a bench-test CSV captured from the Arduino serial
% telemetry and report the same metrics the simulation validates: 
% sensor-based suitability, low-power mode timing, wall-avoidance 
% turn count, and seed dispensing rate.
%
% Expected columns:
%   time_ms, humidity, light_pct, soil_pct, battery_V, dist_cm,
%   suitable, low_power, heading, seeds_planted, out_of_seeds

    if nargin < 1
        csvPath = 'bench_test_01.csv';
    end
    T = readtable(csvPath);

    durationMin = (T.time_ms(end)-T.time_ms(1))/60000;
    fprintf('Bench Test Analysis: %s\n', csvPath);
    fprintf('  Samples: %d,  Duration: %.1f min\n', height(T), durationMin);
    fprintf('  Battery: start %.2f V, end %.2f V\n', T.battery_V(1), T.battery_V(end));
    fprintf('  Time in low-power mode: %.1f%% of session\n', 100*mean(T.low_power));
    fprintf('  Time conditions marked suitable: %.1f%% of session\n', 100*mean(T.suitable));
    turns = sum(diff(T.heading) ~= 0);
    fprintf('  Wall avoidance direction changes: %d\n', turns);
    fprintf('  Seeds planted: %d (%.1f seeds/min average)\n', ...
        T.seeds_planted(end), T.seeds_planted(end)/max(durationMin,1e-6));
    if any(T.out_of_seeds)
        fprintf('  Hopper ran empty during this session.\n');
    end

    figure('Position',[100 100 900 650]);
    subplot(4,1,1);
    plot(T.time_ms/1000, T.battery_V, 'Color',[0.1 0.45 0.25],'LineWidth',1.4);
    ylabel('Battery (V)'); title(sprintf('Bench Test: %s', csvPath)); grid on;
    subplot(4,1,2);
    plot(T.time_ms/1000, T.soil_pct, 'Color',[0.55 0.35 0.1]); hold on;
    plot(T.time_ms/1000, T.humidity, 'Color',[0.2 0.4 0.7]);
    legend('Soil moisture %','Humidity %'); grid on;
    subplot(4,1,3);
    plot(T.time_ms/1000, T.dist_cm, 'Color',[0.4 0.4 0.4]); hold on;
    yline(20, '--r');
    ylabel('Distance (cm)'); grid on;
    subplot(4,1,4);
    plot(T.time_ms/1000, T.seeds_planted, 'Color',[0.1 0.3 0.6],'LineWidth',1.6);
    ylabel('Seeds planted'); xlabel('Time (s)'); grid on;
    saveas(gcf, [csvPath '_analysis.png']);
end
