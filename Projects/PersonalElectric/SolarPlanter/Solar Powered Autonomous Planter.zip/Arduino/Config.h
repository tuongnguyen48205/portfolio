/*
  pin map, thresholds, and timing constants
  All tunable behavior lives here
*/
#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// Pin assignments 
namespace Pins {
  constexpr uint8_t DHT_SENSOR     = 2;   // DHT22 humidity/temperature
  constexpr uint8_t LIGHT          = A0;  // LDR light sensor (analog)
  constexpr uint8_t SOIL           = A1;  // Resistive soil-moisture probe
  constexpr uint8_t BATTERY        = A2;  // Battery voltage divider
  constexpr uint8_t HOPPER_IR      = A3;  // Hopper-empty IR reflectance sensor
  constexpr uint8_t ULTRA_TRIG     = 3;   // HC-SR04 trigger
  constexpr uint8_t ULTRA_ECHO     = 4;   // HC-SR04 echo
  constexpr uint8_t LED_RED        = 5;   // Status LED: conditions unsuitable
  constexpr uint8_t LED_GREEN      = 6;   // Status LED: conditions suitable
  constexpr uint8_t ACTUATOR_SERVO = 9;   // Linear actuator / drill servo
  constexpr uint8_t HEARTBEAT      = 13;  // Onboard LED, blinks once per main loop tick
  // Motor shield + LCD are I2C (SDA/SCL) — no discrete pins to declare.
}

// Planting-condition thresholds 
namespace Thresholds {
  constexpr float SOIL_MIN_PCT     = 25.0f;
  constexpr float SOIL_MAX_PCT     = 75.0f;
  constexpr float HUMIDITY_MIN_PCT = 30.0f;
  constexpr float HUMIDITY_MAX_PCT = 85.0f;
  constexpr float LIGHT_MIN_PCT    = 15.0f;
  constexpr uint8_t SUITABILITY_DEBOUNCE_READS = 3; // consecutive agreeing reads before flipping state

  constexpr float WALL_DISTANCE_CM = 20.0f;
  constexpr uint8_t DIST_MEDIAN_WINDOW = 3;         // median-of-3 filter on ultrasonic

  constexpr uint8_t HOPPER_EMPTY_STREAK_LIMIT = 3;  // consecutive misses -> "out of seeds"
}

// Battery / power management
namespace Power {
  constexpr float BATTERY_FULL_V  = 8.4f;   // 2S pack (or 6xAA) full-charge reference
  constexpr float BATTERY_EMPTY_V = 5.6f;   // treated as 0%

  // Hysteresis bands 
  constexpr float CONSERVE_ENTER_PCT = 35.0f;
  constexpr float CONSERVE_EXIT_PCT  = 45.0f;
  constexpr float CRITICAL_ENTER_PCT = 15.0f;
  constexpr float CRITICAL_EXIT_PCT  = 25.0f;

  constexpr float SPEED_SCALE_NORMAL   = 1.00f;
  constexpr float SPEED_SCALE_CONSERVE = 0.70f;
  constexpr float SPEED_SCALE_CRITICAL = 0.45f;

  constexpr unsigned long POLL_INTERVAL_NORMAL_MS   = 500;
  constexpr unsigned long POLL_INTERVAL_CONSERVE_MS = 1000;
  constexpr unsigned long POLL_INTERVAL_CRITICAL_MS = 2000;

  constexpr unsigned long BACKLIGHT_DUTY_PERIOD_MS = 3000; // on/off period when duty-cycled
}

//  Motion timing 
namespace Motion {
  constexpr unsigned long RAMP_MS           = 250;  // soft-start/stop ramp duration
  constexpr unsigned long HOP_DURATION_MS   = 900;  // forward hop between plantings (normal)
  constexpr unsigned long BACKUP_MS         = 300;  // reverse before turning
  constexpr unsigned long TURN_MS_MIN       = 450;
  constexpr unsigned long TURN_MS_MAX       = 750;
  constexpr uint8_t MOTOR_SPEED_BASE        = 200;  // 0-255, scaled by PowerManager
}

// Seed dispensing cycle
namespace Dispensing {
  constexpr unsigned long EXTEND_MS       = 350;
  constexpr unsigned long SETTLE_MS       = 120;   // wait for seed to settle before checking IR
  constexpr unsigned long RETRACT_MS      = 300;
  constexpr unsigned long TARGET_SEED_INTERVAL_MS = 5450; // -> 11+ seeds/min budget
}

// EEPROM layout 
namespace Storage {
  constexpr uint16_t MAGIC = 0xA53C; // validity marker for first-boot detection
  constexpr int ADDR_BASE  = 0;
}

#endif 
