module Time_sw(input clk, start, reset,
				output [6:0] tenths, output [5:0] secs, mins);
   localparam N = 500000; // For a tenth of a second
   localparam BW = $clog2(N);
   wire [BW-1:0] tick;

   Counter_sw #(.MAX(N-1), .WIDTH(BW)) divider_sw(.clk(clk), 
				.reset(reset), .enable(start), .cnt(tick));
   Counter_sw #(.MAX(99), .WIDTH(7)) ms_sw(.clk(clk), 
				.reset(reset), .enable(tick == 1), .cnt(tenths));
	Counter_sw #(.MAX(59), .WIDTH(6)) cs_sw(.clk(clk), 
				.reset(reset), .enable(tenths == 0 && tick == 2), .cnt(secs));
	Counter_sw #(.MAX(59), .WIDTH(6)) cm_sw(.clk(clk), 
				.reset(reset), .enable(secs == 0 && tenths == 0 && tick == 3), 
				.cnt(mins));
    
endmodule

