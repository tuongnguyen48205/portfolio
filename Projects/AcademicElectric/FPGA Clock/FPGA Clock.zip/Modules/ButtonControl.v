module ButtonControl(input clk, input [2:0] key, output [3:0] display);

	// Mode module
	Mode mode(.clk(clk), .in(!key[2]), .out(display[1:0]));
	
	// The following FastAdvance module 
	FastAdvance plus(.clk(clk), .in(!key[1]), .out(display[3]));
	FastAdvance minus(.clk(clk), .in(!key[0]), .out(display[2]));
endmodule
	