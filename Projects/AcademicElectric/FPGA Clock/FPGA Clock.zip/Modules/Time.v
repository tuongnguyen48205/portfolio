module Time(input clk, input [3:0] edit,
				output [5:0] secs, mins, output [4:0] hrs);
   localparam N = 50000000; 
   localparam BW = $clog2(N);
   wire [BW-1:0] tick;
	
	// Make it so only the flashing digit can be edited
	wire editablesecs;
	wire editablemins;
	wire editablehrs;
	// state 00 is seconds, state 10 is minutes and state 11 is hours
	assign editablesecs = (edit[1:0] == 2'b01) ? 1'b1 : 1'b0;
	assign editablemins = (edit[1:0] == 2'b10) ? 1'b1 : 1'b0;
	assign editablehrs = (edit[1:0] == 2'b11) ? 1'b1 : 1'b0;
	
   Counter #(.MAX(N-1), .WIDTH(BW)) divider(.clk(clk), .enable(edit[1:0] == 2'b00), 
			.plus(edit[3]), .minus(edit[2]), .editable(1'b1), .cnt(tick));
   Counter #(.MAX(59), .WIDTH(6)) cs(.clk(clk), .enable(tick == 0), 
			.plus(edit[3]), .minus(edit[2]), .editable(editablesecs), .cnt(secs));
	Counter #(.MAX(59), .WIDTH(6)) cm(.clk(clk), .enable(secs == 0 && tick == 1), 
			.plus(edit[3]), .minus(edit[2]), .editable(editablemins), .cnt(mins));
	Counter #(.MAX(23), .WIDTH(5)) ch(.clk(clk), .enable(mins == 0 && secs == 0 && tick == 2), 
			.plus(edit[3]), .minus(edit[2]), .editable(editablehrs), .cnt(hrs));
    
endmodule