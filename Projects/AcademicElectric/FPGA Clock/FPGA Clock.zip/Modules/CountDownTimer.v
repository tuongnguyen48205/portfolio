module CountDownTimer(
							input clk, 
							input [2:0] in, 
							output [5:0] secs, mins,
							output [4:0] hrs,
							output reg led);
	// Get the user input
	wire starter;
	reg start;
	wire increment;
	wire reset;
	RisingEdgeDetector red_start(.clk(clk), .in(!in[0]), .out(starter));
	
	// Detect when the counter has reached 0
	//reg led = 0;
	always @(posedge clk) begin
		if (starter) begin
			start <= !start;
			led <= 0;
		end
		else if (secs == 59 && mins == 59 && hrs == 23) begin
			led <= 1;
			start <= 0;
		end
		else begin
			led <= 0;
		end
		
		if (reset) begin
			led <= 0;
		end
	end
	
	FastAdvance plus(.clk(clk), .in(!in[1]), .out(increment));
	RisingEdgeDetector red_reset(.clk(clk), .in(!in[2]), .out(reset));
	
	// Time module
	Time_cdt timerUP(.clk(clk), .start(start), .increment(increment),
					.reset(reset), .secs(secs), .mins(mins), .hrs(hrs));
	

								
	//assign LEDR[0] = led;
								
endmodule




