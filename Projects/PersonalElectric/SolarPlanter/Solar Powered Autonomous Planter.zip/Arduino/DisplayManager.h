/*
  Manages the 16x2 I2C LCD and the two status LEDs.
*/
#ifndef DISPLAY_MANAGER_H
#define DISPLAY_MANAGER_H

#include <Arduino.h>
#include <LiquidCrystal_I2C.h>
#include "Config.h"

class DisplayManager {
public:
  void begin();

  // Normal operating display: LEDs reflect suitability, line 1 shows seed
  // count, line 2 shows/clears the transient message as it expires.
  void update(unsigned long nowMs, uint32_t seedCount, bool conditionsSuitable, bool backlightOn);

  void showTransientMessage(const char *msg, unsigned long durationMs);
  void showOutOfSeeds(uint32_t totalPlanted);
  void updateOutOfSeedsBlink(unsigned long nowMs);
  void resetAfterRefill();

private:
  LiquidCrystal_I2C _lcd{0x27, 16, 2};

  uint32_t _lastShownCount = 0xFFFFFFFFUL;
  bool _transientActive = false;
  unsigned long _transientUntilMs = 0;
  bool _lastBacklightState = true;
  bool _outOfSeedsShown = false;
  unsigned long _lastBlinkToggleMs = 0;
  bool _blinkState = false;

  void writeLine1SeedCount(uint32_t count);
  void writeLine2(const char *text);
};

#endif 
