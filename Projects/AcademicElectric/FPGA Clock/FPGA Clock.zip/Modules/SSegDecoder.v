module SSegDecoder(input clk, input [3:0] digit, input flash,
						output reg [6:0] sseg);
						
	always @(posedge clk)
		if (flash)
			sseg <= 7'b1111111;
		else 
			case(digit)
				0: sseg <= 7'b1000000;
				1: sseg <= 7'b1111001;
				2: sseg <= 7'b0100100;
				3: sseg <= 7'b0110000;
				4: sseg <= 7'b0011001;
				5: sseg <= 7'b0010010;
				6: sseg <= 7'b0000010;
				7: sseg <= 7'b1111000;
				8: sseg <= 7'b0000000;
				9: sseg <= 7'b0010000;
				default: sseg <= 7'b1111111;
			endcase
endmodule