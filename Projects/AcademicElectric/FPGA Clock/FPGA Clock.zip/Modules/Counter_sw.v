module Counter_sw
	#(parameter MAX = 1, WIDTH = 1, UP = 1) (
		input clk,
		input reset,
      input enable,
      output reg [WIDTH - 1:0] cnt
	);
	
	initial cnt = 0;
	
	reg [WIDTH-1:0] next_cnt;
  
   always @(posedge clk) begin
		if (enable) cnt <= next_cnt;
		if (reset) cnt <= 1'd0;
	end
	
	always @(*) 
		next_cnt = (cnt == MAX) ? 1'd0 : (cnt + 1'd1);

endmodule



