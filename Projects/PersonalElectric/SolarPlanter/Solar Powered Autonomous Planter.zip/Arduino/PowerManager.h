/*
  adaptive load control.
  Three power modes (NORMAL / CONSERVE / CRITICAL) driven by battery percentage,
  with hysteresis 
*/
#ifndef POWER_MANAGER_H
#define POWER_MANAGER_H

#include <Arduino.h>
#include "Config.h"

enum class PowerMode : uint8_t { NORMAL, CONSERVE, CRITICAL };

class PowerManager {
public:
  void update(float batteryPct, unsigned long nowMs);

  PowerMode mode() const { return _mode; }
  bool justChangedMode() const { return _modeChangedThisUpdate; }

  float motorSpeedScale() const;
  unsigned long pollIntervalMs() const;
  unsigned long hopDurationMs() const;

  // In CRITICAL mode, alternate skipping planting opportunities to stretch
  // remaining charge further — still moves/senses, just plants half as often.
  bool shouldSkipThisPlantingOpportunity();

  // LCD backlight duty-cycles in CONSERVE/CRITICAL to shed non critical load.
  bool backlightShouldBeOn(unsigned long nowMs) const;

  const __FlashStringHelper* modeName() const;

private:
  PowerMode _mode = PowerMode::NORMAL;
  bool _modeChangedThisUpdate = false;
  bool _skipToggle = false;
};

#endif 
