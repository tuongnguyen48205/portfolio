# Seed-Planting Rover

## Contents

**diagrams_and_renders/**
- `system_flowchart.png` — embedded control-flow flowchart.
- `power_block_diagram.png` — power-system architecture.
- `fig_battery_conservation.png`, `fig_variation_and_loss.png` — simulation
  results.

**arduino/seed_planter_controller/** 
- `seed_planter_controller.ino` — top-level module
- `Config.h` Pin layout
- `Filters.h` EMA filter + median of 3, used to smooth/de-noise every
  analog reading
- `SensorSuite.*` reads + filters humidity, light, soil moisture, battery,
  ultrasonic; debounces the planting-suitability decision (3 consecutive
  agreeing reads before flipping) so it doesn't flicker at a threshold.
- `PowerManager.*` three-tier adaptive load control (NORMAL/CONSERVE/
  CRITICAL) with hysteresis (separate enter/exit thresholds), scaling motor
  speed, poll rate, hop distance, and even skipping every-other planting
  opportunity in CRITICAL mode to stretch remaining charge.
- `Drivetrain.*` non blocking motor control with soft start/stop ramping
  (reduces current inrush on the shared solar/battery bus) and a
  back up then pivot wall avoidance maneuver
- `Dispenser.*` non-blocking plant cycle state machine (extend → settle →
  check hopper → retract) with debounced hopper empty detection.
- `DisplayManager.*` LCD + status LEDs, with a transient message system so
  "Changing Direction" can't be instantly overwritten by a routine refresh.
- `StorageManager.*` EEPROM persistence for lifetime seed count, lifetime
  runtime, and soil sensor dry/wet calibration
- `SerialCommands.*` a text command interface over serial (`STATUS`,
  `CAL_SOIL_DRY`, `CAL_SOIL_WET`, `REFILL_HOPPER`, `RESET_SESSION`,
  `RESET_LIFETIME`) for field calibration and diagnostics

**matlab/**
- `solar_power_simulation.m` — PV array + adaptive load controller model
  (32-cycle bus-regulation validation) plus a low-battery adaptive
  conservation scenario (deep overcast/low light drain test) showing
  extended runtime and more seeds planted per charge.
- `analyze_test_log.m` — analyzes real Arduino bench-test CSVs against the
  same metrics.

**[Seed planter presentation.](<Solar-Powered Autonomous Planter Presentation.pdf>)** — 13 slide overview.
**[Seed planter flowchart.](<Solar-Powered Autonomous Planter Flowchart.pdf>)** 