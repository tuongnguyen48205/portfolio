module Watch(
	input CLOCK_50, 
	input [3:0] KEY,
	output [6:0] HEX5, HEX4, HEX3, HEX2, HEX1, HEX0,
	output [9:0] LEDR
	);
	
	// To determine the mode. 
	wire [3:0] clockMode;
	wire [3:0] key0;
	wire [3:0] key1;
	wire [3:0] key2;
	ModeSelector modeselector(.clk(CLOCK_50), 
										.btn3(!KEY[3]), .btn2(!KEY[2]), .btn1(!KEY[1]), .btn0(!KEY[0]), 
										.clockmode(clockMode),
										.key0(key0), .key1(key1), .key2(key2));
	assign LEDR[9:6] = clockMode;
	
	// For the clock
	wire [5:0] secs;
	wire [5:0] mins;
	wire [4:0] hrs;
	wire [3:0] flash_digit;
	wire [2:0] clock_in;
	assign clock_in = {key2[0], key1[0], key0[0]};
	Clock clock(.clk(CLOCK_50), .in(clock_in), .secs(secs), .mins(mins), .hrs(hrs), .flash(flash_digit));

	// For the stopwatch
	wire [6:0] tenths_sw;
	wire [5:0] secs_sw;
	wire [5:0] mins_sw;
	wire [2:0] stopwatch_in;
	assign stopwatch_in = {key2[1], key1[1], key0[1]};
	StopWatch stopwatch(.clk(CLOCK_50), .in(stopwatch_in), .tenths(tenths_sw), .secs(secs_sw), .mins(mins_sw));
	
	// For the countdown timer
	wire [5:0] secs_cdt;
	wire [5:0] mins_cdt;
	wire [4:0] hrs_cdt;
	wire [2:0] countdowntimer_in;
	assign countdowntimer_in = {key2[2], key1[2], key0[2]};
	CountDownTimer countdowntimer(.clk(CLOCK_50), .in(countdowntimer_in), 
											.secs(secs_cdt), .mins(mins_cdt), .hrs(hrs_cdt), .led(LEDR[0]));
											
	// For the gambling mode
	wire [6:0] tokens;
	wire [6:0] bet;
	wire win;
	wire [2:0] gambling_in;
	assign gambling_in = {key2[3], key1[3], key0[3]};
	Gambling gambling(.clk(CLOCK_50), .in(gambling_in), .tokens(tokens), .bet(bet), .win(LEDR[3:2]));
	
	// Now display everything
	Display display_secs(.clk(CLOCK_50), .num(secs), .num2(tenths_sw), .num3(secs_cdt), .num4(tokens), 
								.flash(flash_digit[1]), .enable(clockMode), .sseg_tens(HEX1), .sseg_ones(HEX0));
	Display display_mins(.clk(CLOCK_50), .num(mins), .num2(secs_sw), .num3(mins_cdt), .num4(0),
								.flash(flash_digit[2]), .enable(clockMode), .sseg_tens(HEX3), .sseg_ones(HEX2));
	Display display_hrs(.clk(CLOCK_50), .num(hrs), .num2(mins_sw), .num3(hrs_cdt), .num4(bet),
								.flash(flash_digit[3]), .enable(clockMode), .sseg_tens(HEX5), .sseg_ones(HEX4));		
								
endmodule