module DeMUX4(input in, input [1:0] sel, output [3:0] out);
    reg [3:0] temp_out;
    
	always @(*)
		case(sel)
			2'b00: temp_out = 4'b0001;
         2'b01: temp_out = 4'b0010;
         2'b10: temp_out = 4'b0100;
         2'b11: temp_out = 4'b1000;
      endcase
    
   assign out = temp_out;
endmodule



