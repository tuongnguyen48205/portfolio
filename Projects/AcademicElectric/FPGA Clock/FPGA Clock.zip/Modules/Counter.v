module Counter
	#(parameter MAX = 1, WIDTH = 1, UP = 1) (
		input clk,
      input enable,
      input plus,
      input minus,
		input editable, 
      output reg [WIDTH - 1:0] cnt
	);
	
	initial cnt = 0;
	
	reg [WIDTH-1:0] next_cnt;
  
   always @(posedge clk) 
		cnt <= next_cnt;
	
	always @(*)
		// If both plus and minus are pressed, do nothing
		if (plus && minus); 
		// If plus is pressed, increment count
		else if (plus && !minus && editable) 
			next_cnt = (cnt == MAX) ? 0 : cnt + 1;
		// If minus is pressed, reduce count
		else if (minus && !plus && editable) 
			next_cnt = (cnt == 0) ? MAX : cnt - 1;
		// If neither is pressed and enable is 1
      else if (enable && !plus && !minus)
			if (UP) 
				next_cnt = (cnt == MAX) ? 0 : cnt + 1;
         else 
				next_cnt = (cnt == 0) ? MAX : cnt - 1;
		else
			next_cnt = cnt;

endmodule



