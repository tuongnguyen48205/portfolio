"""
Test network: WSCC 9-Bus System

A widely used small transmission network consisting of:
  - 3 generator buses (1 slack + 2 PV)
  - 3 load buses (PQ)
  - 3 junction buses (no injection)
  - 3 step-up transformers (generator -> transmission voltage)
  - 6 transmission lines (230 kV level)

All quantities are in per-unit on a 100 MVA system base unless noted.
Voltage bases: Bus 1 = 16.5 kV, Bus 2 = 18.0 kV, Bus 3 = 13.8 kV,
               Buses 4-9 = 230 kV.

This dataset is used as the reference transmission network for all
analyses in this project (base case power flow, N-1 contingency
screening, voltage stability / loading scans, transformer thermal
loading checks and fault-current calculations).
"""

import numpy as np

S_BASE_MVA = 100.0

# ---------------------------------------------------------------------------
# Bus data
# type: 'slack', 'PV', 'PQ'
BUS_DATA = {
    1: {"type": "slack", "v_set": 1.040, "base_kv": 16.5},
    2: {"type": "PV",    "v_set": 1.025, "base_kv": 18.0},
    3: {"type": "PV",    "v_set": 1.025, "base_kv": 13.8},
    4: {"type": "PQ",    "v_set": 1.000, "base_kv": 230.0},
    5: {"type": "PQ",    "v_set": 1.000, "base_kv": 230.0},
    6: {"type": "PQ",    "v_set": 1.000, "base_kv": 230.0},
    7: {"type": "PQ",    "v_set": 1.000, "base_kv": 230.0},
    8: {"type": "PQ",    "v_set": 1.000, "base_kv": 230.0},
    9: {"type": "PQ",    "v_set": 1.000, "base_kv": 230.0},
}
N_BUS = len(BUS_DATA)

# ---------------------------------------------------------------------------
# Generator data  (P in MW, Qmax/Qmin in MVAr, at 100 MVA base)
GEN_DATA = {
    1: {"P_mw": None, "Qmin": -300, "Qmax": 300},   # slack: P solved by the study
    2: {"P_mw": 163.0, "Qmin": -300, "Qmax": 300},
    3: {"P_mw": 85.0,  "Qmin": -300, "Qmax": 300},
}

# ---------------------------------------------------------------------------
# Load data (constant-power PQ loads, MW / MVAr)
LOAD_DATA = {
    5: {"P_mw": 125.0, "Q_mvar": 50.0},
    6: {"P_mw": 90.0,  "Q_mvar": 30.0},
    8: {"P_mw": 100.0, "Q_mvar": 35.0},
}

# ---------------------------------------------------------------------------
# Transmission line data: (from, to): R, X, B (total line charging, pu)
LINE_DATA = {
    ("4", "5"): {"R": 0.0100, "X": 0.0850, "B": 0.176, "rate_mva": 250},
    ("4", "6"): {"R": 0.0170, "X": 0.0920, "B": 0.158, "rate_mva": 200},
    ("5", "7"): {"R": 0.0320, "X": 0.1610, "B": 0.306, "rate_mva": 150},
    ("6", "9"): {"R": 0.0390, "X": 0.1700, "B": 0.358, "rate_mva": 150},
    ("7", "8"): {"R": 0.0085, "X": 0.0720, "B": 0.149, "rate_mva": 250},
    ("8", "9"): {"R": 0.0119, "X": 0.1008, "B": 0.209, "rate_mva": 250},
}

# ---------------------------------------------------------------------------
# Transformer data: (from, to): X (R assumed negligible), MVA rating
XFMR_DATA = {
    ("1", "4"): {"R": 0.0, "X": 0.0576, "rate_mva": 250},   # Gen1 GSU
    ("2", "7"): {"R": 0.0, "X": 0.0625, "rate_mva": 200},   # Gen2 GSU
    ("3", "9"): {"R": 0.0, "X": 0.0586, "rate_mva": 100},   # Gen3 GSU
}

ALL_BRANCHES = {**LINE_DATA, **XFMR_DATA}

def branch_list():
    """
    Return list of (from_bus:int, to_bus:int, data_dict, is_transformer:bool).
    """
    out = []
    for (f, t), d in LINE_DATA.items():
        out.append((int(f), int(t), d, False))
    for (f, t), d in XFMR_DATA.items():
        out.append((int(f), int(t), d, True))
    return out
