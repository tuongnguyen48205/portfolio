module Flash(input clk, output reg out);

	reg [24:0] counter = 0;  

	always @(posedge clk) 
		// 50000000Hz / 25000000 = 2 Hz
		if (counter < 25_000_000) 
			counter <= counter + 1;
		else
			counter <= 0;

	// The duty cycle
	always @(posedge clk) 
		// 25000000 * 0.8 = 20000000
		if (counter < 20_000_000)  
			out <= 1; 
		else
			out <= 0;  

endmodule



