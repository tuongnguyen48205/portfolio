module ModeSelector(
	input clk, 
	input btn3, btn2, btn1, btn0,
	output wire [3:0] clockmode,
	output wire [3:0] key0, key1, key2
	);
	
	// To get the input
	wire out;
	RisingEdgeDetector red_modeselector(.clk(clk), .in(btn3), .out(out));
	
	// states
	localparam clock = 4'b0001, stopwatch = 4'b0010, countdown = 4'b0100, gambling = 4'b1000;
	reg [3:0] state, next_state;
	
	initial state = clock;
	
	always @(posedge clk)
		state <= next_state;
		
	always @(*)
		case(state)
			clock: next_state = (out) ? stopwatch : clock;
			stopwatch: next_state = (out) ? countdown : stopwatch;
			countdown: next_state = (out) ? gambling : countdown;
			gambling: next_state = (out) ? clock : gambling;
			default: next_state = clock;
		endcase
		
	assign clockmode = state;
	
	// Now multiplexer for the button
	reg [3:0] key0_temp = 0;
	reg [3:0] key1_temp = 0;
	reg [3:0] key2_temp = 0;
	
	always @(*) begin
		if (clockmode == clock) begin
			key0_temp[0] = (btn0) ? 0 : 1;
			key1_temp[0] = (btn1) ? 0 : 1;
			key2_temp[0] = (btn2) ? 0 : 1;
		end
		if (clockmode == stopwatch) begin
			key0_temp[1] = (btn0) ? 0 : 1;
			key1_temp[1] = (btn1) ? 0 : 1;
			key2_temp[1] = (btn2) ? 0 : 1;
		end
		if (clockmode == countdown) begin
			key0_temp[2] = (btn0) ? 0 : 1;
			key1_temp[2] = (btn1) ? 0 : 1;
			key2_temp[2] = (btn2) ? 0 : 1;
		end
		if (clockmode == gambling) begin
			key0_temp[3] = (btn0) ? 0 : 1;
			key1_temp[3] = (btn1) ? 0 : 1;
			key2_temp[3] = (btn2) ? 0 : 1;
		end
	end	

	assign key0 = key0_temp;
	assign key1 = key1_temp;
	assign key2 = key2_temp;
		
endmodule
	
	
	