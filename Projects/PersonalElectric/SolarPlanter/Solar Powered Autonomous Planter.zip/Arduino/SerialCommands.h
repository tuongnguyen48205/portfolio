/*
  a small text command interface over the USB serial link,
  separate from the CSV telemetry stream. Lets you calibrate the soil sensor,
  check status, or reset counters in the field without reflashing firmware.

  Commands (newline-terminated, case-insensitive):
    HELP              — list commands
    STATUS            — print current sensor/power/dispenser snapshot
    CAL_SOIL_DRY      — sample the soil probe in air/dry soil, store as 0% point
    CAL_SOIL_WET      — sample the soil probe in saturated soil, store as 100% point
    REFILL_HOPPER     — clear the "out of seeds" latch after a manual refill
    RESET_SESSION     — zero the current session's seed counter
    RESET_LIFETIME    — zero the EEPROM lifetime seed/runtime counters
*/
#ifndef SERIAL_COMMANDS_H
#define SERIAL_COMMANDS_H

#include <Arduino.h>
#include "SensorSuite.h"
#include "StorageManager.h"
#include "Dispenser.h"
#include "PowerManager.h"

class SerialCommands {
public:
  void begin();
  void poll(SensorSuite &sensors, StorageManager &storage, Dispenser &dispenser, PowerManager &power);

private:
  char _buf[32];
  uint8_t _len = 0;

  void handleCommand(const char *cmd, SensorSuite &sensors, StorageManager &storage,
                     Dispenser &dispenser, PowerManager &power);
};

#endif 
