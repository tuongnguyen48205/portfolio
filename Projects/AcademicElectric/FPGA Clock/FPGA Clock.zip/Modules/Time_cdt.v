module Time_cdt(input clk, start, increment, reset,
				output [5:0] secs, mins, output [4:0] hrs);
   localparam N = 50000000; 
   localparam BW = $clog2(N);
   wire [BW-1:0] tick;
	
	Counter_cdt #(.MAX(N-1), .WIDTH(BW)) divider1(.clk(clk), 
				.reset(reset), .increment(1'd0), .enable(start), .cnt(tick));
	Counter_cdt #(.MAX(59), .WIDTH(6)) cs1(.clk(clk), 
				.reset(reset), .increment(increment), .enable(tick == 1), .cnt(secs));
	Counter_cdt #(.MAX(59), .WIDTH(6)) cm1(.clk(clk), 
				.reset(reset), .increment(increment && secs == 59), 
				.enable(secs == 0 && tick == 2), .cnt(mins));
	Counter_cdt #(.MAX(23), .WIDTH(5)) ch1(.clk(clk), 
				.reset(reset), .increment(increment && (mins == 59 && secs == 59)), 
				.enable(mins == 0 && secs == 0 && tick == 3), .cnt(hrs));
    
endmodule

